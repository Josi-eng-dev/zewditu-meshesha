# Implementation Plan — Zewditu Public Website MVP

**Version:** 1.0  
**Date:** 2026-10-21  
**Rule:** Documentation and organizational confirmations before application scaffolding.

## Locked decisions

- MVP areas: Home, About, Activities, Donate, Contact, Gallery, News  
- Out: payments, auth/accounts, admin CMS, vacancy workflows, chat/apps, unverified stats  
- Stack: Vue 3 + TS + Vite · Java 21 Spring Boot · Maven · REST `/api/v1` · modular monolith  
- PostgreSQL: conditional (ADR-002)  
- Donations: verified static instructions + pledge form  
- Contact: verified delivery or channels-only (ADR-004)

## Git baseline

| Branch | Role |
| --- | --- |
| `main` (`f676b59`) | **Canonical** integration tip (PR #1 merge); tree identical to `zewditu` |
| `zewditu` (`c4bdd7d`) | Extraction feature branch; already contained in `main` tree |

No automatic merge/switch/commit in the docs package. Details: [`docs/audit/09-technical-observations.md`](audit/09-technical-observations.md).

## Phased roadmap

### P0 — Discovery & audit completion (current docs milestone)

- Reconcile inventories; complete audit docs 01–11  
- Record unknowns; draft migration candidates  
- **Exit:** Audit handoff accepted for planning  

### P1 — Product requirements

- Finalize audience, journeys, functional/NFR, content governance, measurable acceptance targets  
- **Exit:** Requirements approved  

### P2 — Architecture & UX

- Confirm stack versions, API contract, persistence, URL strategy, design system, SEO rendering, hosting cost  
- Accept/update ADRs 002–004  
- **Exit:** Architecture and design approved  

### P3 — Foundation (first coding milestone)

- Scaffold `frontend/` and `backend/` builds, lint, tests, CI, local env, OpenAPI stub  
- **Exit:** Reproducible builds and automated checks pass  

### P4 — Public website implementation

- Shared layout + seven areas + news/gallery/donate/contact behavior per approved decisions  
- **Exit:** Feature acceptance criteria pass  

### P5 — Content migration & QA

- Migrate approved material; redirects; a11y/security/responsive/performance  
- **Exit:** Release candidate verified  

### P6 — Organizational acceptance & launch

- Final approval, deploy, production verify, operations handover  
- **Exit:** Authorized launch  

Effort estimates and calendar dates intentionally omitted until foundation inspection and open requirements close.

## Documentation map

| Deliverable | Path |
| --- | --- |
| Audit set | `docs/audit/` |
| MVP requirements | `docs/product/mvp-requirements.md` |
| Migration plan | `docs/product/content-migration-plan.md` |
| System design | `docs/architecture/system-design.md` |
| ADRs | `docs/architecture/decisions/` |
| Runbook | `docs/operations/runbook.md` |
| Acceptance checklist | `docs/testing/acceptance-checklist.md` |
| Current snapshot | `docs/CURRENT-STATE.md` |

## What we do next (after this package is reviewed)

1. Resolve critical unknowns (especially U01–U04, U06, U15).  
2. Accept ADRs 002–004.  
3. Only then start P3 scaffolding — **no application code before that gate**.

## Explicit non-actions for the docs package

- No frontend/backend scaffolding  
- No Docker/CI implementation  
- No database schemas  
- No git commit/push/merge/branch switch automation  
