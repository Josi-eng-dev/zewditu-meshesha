# ADR 003 — Frontend Rendering & SEO

- **Status:** Open — evaluate before locking frontend foundation
- **Date:** 2026-10-21
- **Decision owner:** Tech lead (volunteer) — name TBD  
- **Acceptance criteria:** For Home and one News article, a crawler/view-source check shows correct title, description, and primary content without requiring a human to execute client JS; choice (CSR / prerender / SSR) recorded as Accepted with that evidence.
- **Context:** Vue 3 + Vite can ship as a CSR SPA. Public charity sites need reliable page-specific titles, descriptions, and crawlable content for Home, About, Activities, Donate, Contact, Gallery, and News articles.

## Options

1. **CSR only** — SPA with client-updated meta tags.  
2. **Prerender** — generate static HTML for known routes at build time.  
3. **SSR** — server-render Vue (e.g. Nuxt) — larger shift from “Vite SPA + separate Spring API”.

## Decision criteria

- Search engines and link unfurls receive correct title/description/canonical per route  
- Amharic content renders correctly in previews  
- Complexity remains maintainable for volunteers  
- Compatible with Spring Boot as content/API source  

## Interim guidance

- Do **not** assume CSR alone is sufficient.  
- During P2/P3, prototype meta tags + crawler view for at least Home and one News article.  
- If CSR fails criteria, prefer **prerender of public routes** before adopting full SSR/Nuxt unless requirements demand it.

## Consequences

- May affect `frontend/` tooling and deployment artifact shape.  
- Final choice must be recorded by updating this ADR to Accepted/Rejected with evidence.
