# ADR 004 — Contact Message Handling

- **Status:** Open — blocked on organizational confirmation (Unknown U04)
- **Date:** 2026-10-21
- **Decision owner:** Org communications + tech lead — names TBD  
- **Acceptance criteria:** (1) Org states form required or not; (2) if required, named mailbox + monitor; (3) staging test proves delivery or channels-only UI ships with no fake success; (4) ADR status set to Accepted Option 1 or 2.
- **Context:** Extracted Contact Us page invites messages/calls but contains **no form fields** in the extraction HTML. MVP must not show “message sent” without a working delivery mechanism.

## Options

1. **Channels only** — display verified phone, email, address; no form.  
2. **Server-side email** — `POST /api/v1/contact-messages` validates input and sends email to a verified organizational address; optional short retention log.  
3. **Store in database only** — **Rejected** unless paired with monitored delivery/workflow (silent inbox is unacceptable).

## Decision (pending)

Await U04 answers:

- Is a form required?  
- Which recipient address?  
- Who monitors and what is the SLA?  
- Retention/deletion policy for submissions?

**Fallback if unanswered by implementation start:** Option 1 (channels only).

## Implementation constraints (if Option 2)

- Server-side validation, CAPTCHA or equivalent abuse control, rate limiting  
- Secrets for SMTP/API via environment  
- Clear failure UX if email send fails  
- Privacy notice for personal data  

## Consequences

- Affects whether PostgreSQL/contact table is needed (ADR-002).  
- Affects API surface and Playwright journeys.
