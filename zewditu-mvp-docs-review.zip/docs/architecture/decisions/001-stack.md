# ADR 001 — Technology Stack

- **Status:** Accepted for tooling preference; **backend role for MVP must be justified per section “MVP backend necessity” below**
- **Date:** 2026-10-21
- **Decision owner (tech):** Project technical lead (volunteer) — name TBD  
- **Acceptance criteria:** Reviewer agrees frontend/backend choices match repo layout and MVP constraints; Spring Boot scope matches the justified MVP duties (not “backend for its own sake”).

## Context

Choose a maintainable stack for a volunteer-built public website MVP with directories `frontend/` and `backend/` already reserved. Content is mostly infrequently updated organizational pages, news, gallery, and static donation instructions.

## Decision

| Layer | Choice |
| --- | --- |
| Frontend | Vue 3, TypeScript, Vite |
| Routing | Vue Router |
| Styling | Tailwind CSS or a lightweight token-based CSS system (finalize at foundation) |
| Backend | Java 21, Spring Boot, Maven |
| API | REST, versioned under `/api/v1` |
| Architecture style | Modular monolith (not microservices) |
| Tests | JUnit 5 / Spring Boot Test; Vitest / Vue Test Utils; Playwright for E2E |
| API docs | OpenAPI |
| Packaging | Docker (later); CI via GitHub Actions (later) |

Pin compatible dependency versions in project files when scaffolding begins — do not rely on unverified “latest”.

## MVP backend necessity (justification — not assumption)

A primarily static charity site **does not automatically require** Spring Boot. Three honest options:

| Option | When appropriate | MVP fit |
| --- | --- | --- |
| **A. Static Vue only** (no backend process) | All content and donation text are build-time files; Contact is channels-only (ADR-004 Option 1); no server-side form | Fully viable if U04 selects channels-only |
| **B. Thin Spring Boot API** | Need server-validated contact email, abuse controls, health checks, or a stable JSON content API for news/gallery without baking every change into a full static rebuild workflow | Justified **only** for those duties |
| **C. Spring Boot + PostgreSQL** | Persistent submissions, audit logs, or queryable content that files cannot cover | Only if ADR-002/004 require it |

**Locked preference for this project:** keep the Spring Boot module in the architecture so Option B is available, but **P3 must implement only justified modules**:

1. **Required in P3 only if U04 = form+email:** `contact` module (validation, rate limit, mail send).  
2. **Optional content API:** serve approved news/pages/gallery from version-controlled files via `/api/v1` *or* ship the same JSON as static assets from the Vue build — choose one approach in P2 and document it.  
3. **Not justified for MVP:** auth, CMS, payments, vacancy workflows, or a database “to have JPA”.

If review concludes Option A is enough for v1.0, Spring Boot scaffolding may be deferred; Vue static hosting proceeds alone. That is an acceptable outcome of this ADR review.

## Consequences

- Matches team preference and empty repo layout when Option B/C is chosen.  
- Requires Java toolchain only when backend is in scope for the release.  
- Does not by itself require PostgreSQL (see ADR-002).  
- SEO approach for Vue must be validated (ADR-003).
