# ADR 002 — Persistence for MVP

- **Status:** Proposed default — **version-controlled content first**; PostgreSQL only if a concrete requirement emerges
- **Date:** 2026-10-21
- **Decision owner:** Tech lead — name TBD  
- **Acceptance criteria:** Written list of every entity that would be stored in Postgres (or explicit “none for MVP”); if none, ADR Accepted as file-based; if contact logs needed, retention/deletion policy attached.
- **Context:** MVP has no admin CMS. Content updates are expected to be infrequent and performed by developers/volunteers with organizational approval. A database must not be added merely to justify Spring Boot.

## Options considered

1. **Version-controlled content + static media** — Markdown/JSON/YAML (or classpath resources) reviewed in Git; media in object storage or static hosting.  
2. **PostgreSQL-backed content** — pages/articles/media metadata in DB; publish via migrations/scripts or future admin.  
3. **Hybrid** — static content for pages; DB only for contact submissions if required.

## Decision (proposed)

- **Default for MVP:** Option 1 (and Option 3 only if ADR-004 requires storing submissions).  
- **Do not** create full Page/Article/Media schemas until a listed requirement needs queryable persistence.  
- If PostgreSQL is introduced, document exactly what is stored, retention, backups, and how content changes are published without a CMS.

## Justification

- Aligns with “no custom admin CMS” MVP constraint.  
- Reduces hosting cost and operational burden for a small charity site.  
- Spring Boot remains useful for validation, contact delivery, OpenAPI, and future growth.

## Consequences

- Content updates require a deployment or controlled content-release process.  
- News/gallery APIs may read from files or an embedded content module rather than JPA entities.  
- Revisit this ADR if the organization later requires frequent non-technical editing (post-MVP CMS).
