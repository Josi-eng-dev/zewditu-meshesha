# Architecture documentation

| Document | Purpose |
| --- | --- |
| [`system-design.md`](system-design.md) | Components, API sketch, deployment |
| [`decisions/001-stack.md`](decisions/001-stack.md) | Stack ADR (accepted) |
| [`decisions/002-persistence.md`](decisions/002-persistence.md) | PostgreSQL vs file content |
| [`decisions/003-rendering-seo.md`](decisions/003-rendering-seo.md) | CSR / prerender / SSR |
| [`decisions/004-contact-handling.md`](decisions/004-contact-handling.md) | Contact form delivery |
