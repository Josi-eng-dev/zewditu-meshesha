# System Design — MVP Public Website

**Status:** Proposed architecture for review  
**Stack lock:** Vue 3 + TypeScript + Vite · Java 21 Spring Boot (Maven) · REST `/api/v1` · modular monolith  
**Related ADRs:** `decisions/001`–`004`

## 1. Context

Rebuild the public digital presence for Zewditu Meshesha Children and Family Welfare and Development Association. MVP is public content + contact/donation information only — no CMS admin, payments, or auth.

## 1.1 Does MVP need Spring Boot?

**Not assumed.** Most MVP pages can be version-controlled content rendered by Vue (static or prerendered). Spring Boot is justified in this MVP **only** for duties that cannot be done safely in the browser alone:

| Duty | Needs Spring Boot? | Notes |
| --- | --- | --- |
| Serve Home/About/Activities/Donate/Gallery text | No (files/static) | Prefer approved content files |
| News list/article JSON | Optional | File-backed API **or** static JSON in the frontend build |
| Donation instructions | No | Static, org-verified copy + pledge file |
| Contact form with email delivery + rate limits | **Yes** | Only if ADR-004 Option 2 |
| Auth, CMS, payments | No | Out of MVP |

Full options and deferral rules: [ADR-001](decisions/001-stack.md) (“MVP backend necessity”).

## 2. Logical architecture

```text
Visitor browser
    │  HTTPS
    ▼
Vue 3 SPA / prerendered public site  (frontend/)
    │  JSON REST /api/v1
    ▼
Spring Boot modular monolith         (backend/)
    ├── public-content
    ├── news
    ├── gallery
    ├── donation-info   (optional if not static)
    ├── contact         (only if delivery path approved)
    └── shared (config, errors, logging, security)
    │
    ├── Approved content files and/or
    └── PostgreSQL (only if ADR-002 selects persistence)
    │
    └── Contact delivery (email) if ADR-004 selects form+email
```

## 3. Frontend responsibilities

- Seven public areas + shared layout/navigation/footer
- Responsive UI, accessibility, SEO metadata
- Central API client; typed responses; loading/empty/error states
- Static assets: approved images/documents under `public/` or CDN
- No global state library unless a real shared-state need appears
- Rendering strategy per ADR-003 (CSR vs prerender/SSR)

Proposed structure (scaffold later — not created in this docs phase):

```text
frontend/
├── public/
├── src/
│   ├── components/
│   ├── layouts/
│   ├── pages/
│   ├── features/{news,gallery,donations,contact}/
│   ├── services/
│   ├── api/
│   ├── router/
│   ├── styles/
│   └── types/
├── tests/
├── package.json
└── vite.config.ts
```

## 4. Backend responsibilities

Single Spring Boot application (not microservices).

| Module | Responsibility |
| --- | --- |
| Public content | Serve approved pages by slug |
| News | List/retrieve approved articles (pagination) |
| Gallery/media | Metadata and approved media references |
| Donation information | Serve verified instructions **if** dynamic delivery is useful; otherwise frontend static content is acceptable |
| Contact | Validate and process messages **only** with approved delivery |
| Shared | Config, consistent errors, logging, security headers, health |

### Candidate API (to finalize with content model)

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/v1/pages/{slug}` | Public page |
| GET | `/api/v1/news` | Paginated news list |
| GET | `/api/v1/news/{slug}` | News article |
| GET | `/api/v1/gallery` | Gallery items |
| GET | `/api/v1/donation-info` | Donation instructions (optional) |
| POST | `/api/v1/contact-messages` | Contact submit (conditional) |
| GET | `/actuator/health` | Health (restricted exposure) |

### Backend rules

- DTOs only at API boundary  
- Server-side validation; bounded list sizes  
- Secrets via environment/config — never committed  
- Rate limiting / abuse protection on public POST  
- No authentication module in MVP  

## 5. Persistence decision (summary)

PostgreSQL is **not** mandatory for MVP. Prefer version-controlled approved content + static media unless contact persistence or similar justifies a database. See [ADR-002](decisions/002-persistence.md).

## 6. Deployment sketch (proposal)

- Vue build as static assets (CDN/web server)  
- Spring Boot as one process/container  
- PostgreSQL only if selected  
- HTTPS, separate env configs, GitHub Actions CI later  
- Docker for reproducibility; **no Kubernetes** for MVP  

Provider selection and costs are Unknown (U09). See [`docs/operations/runbook.md`](../operations/runbook.md).

## 7. Security & safeguarding baseline

HTTPS; validated inputs; request size limits; no stack traces to clients; minimum PII; child media consent gate before publishing; dependency patching; no default analytics/ad pixels.

## 8. Out of scope for this design

Admin app (`admin/`), microservices, payment gateways, OAuth/user accounts, mobile apps.
