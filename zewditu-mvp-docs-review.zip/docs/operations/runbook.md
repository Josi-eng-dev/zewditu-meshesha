# Operations Runbook (MVP Draft)

**Status:** Outline — provider and owners TBD (Unknown U09)  
**Scope:** Public Vue site + Spring Boot API; PostgreSQL only if selected

## 1. Environments

| Environment | Purpose |
| --- | --- |
| Local | Developer machines |
| Staging | Content and integration verification |
| Production | Public site |

Use separate configuration per environment. Never commit secrets.

## 2. Proposed runtime topology

- Frontend: static build on web server or CDN  
- Backend: single Spring Boot process or container  
- Database: only if ADR-002 requires it  
- TLS terminated at load balancer or reverse proxy  
- Health: `/actuator/health` with restricted exposure  

Docker may be used for reproducibility. Kubernetes is out of MVP scope.

## 3. Secrets & configuration

- Store SMTP, DB, and API credentials outside git (host secrets / `.env` not committed)  
- Maintain `.env.example` with **placeholder keys only** when scaffolding begins  
- Rotate credentials on staff changes  

## 4. Deployment (to refine with provider)

1. CI runs tests and builds  
2. Deploy backend artifact/container to staging  
3. Deploy frontend assets to staging  
4. Smoke-test critical journeys  
5. Promote to production with change record  
6. Document rollback (previous artifact + DNS/config)  

## 5. Backups & recovery

- If PostgreSQL used: automated backups, tested restore, retention policy  
- If file-based content: git history is the backup for content; media backups still required  
- Pledge forms and approved media stored in durable storage with access control  

## 6. Monitoring & incidents

- Uptime check on public homepage and API health  
- Centralize application logs; no PII in logs where avoidable  
- Incident contacts and escalation — **assign before launch**  

## 7. Ownership after handover

Document named owners for:

- Domain renewal  
- Hosting payments  
- Dependency updates / security patches  
- Content approval  
- Incident response  

## 8. Provider selection checklist

Before choosing hosting, verify: price, Java hosting support, optional Postgres, regional accessibility, backup costs, TLS, and the organization’s ability to operate the service. Do not assume free tiers remain free.
