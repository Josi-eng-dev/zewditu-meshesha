# Zewditu Meshesha Digital Platform

A complete digital platform rebuild for Zewditu Meshesha Children and Family Welfare and Development Association.

This project is being developed as a volunteer charitable contribution to modernize the organization's digital presence and supporting systems.

## Project Status

**Phase:** Phase 0 complete (docs package) → Phase 1 product confirmation  

**Status:** Documentation package ready for review — **application implementation not started**

**MVP (locked):** Public website only — Home, About, Activities, Donate, Contact, Gallery, News  

**Stack (locked):** Vue 3 + TypeScript + Vite · Java 21 Spring Boot (Maven) · REST `/api/v1` · modular monolith  

## Start here

| Document | Purpose |
| --- | --- |
| [`docs/CURRENT-STATE.md`](docs/CURRENT-STATE.md) | Snapshot of repo and live-site extraction status |
| [`docs/IMPLEMENTATION-PLAN.md`](docs/IMPLEMENTATION-PLAN.md) | Phased roadmap P0–P6 |
| [`docs/product/mvp-requirements.md`](docs/product/mvp-requirements.md) | MVP scope and acceptance goals |
| [`docs/audit/`](docs/audit/) | Reconciled Phase 0 audit |
| [`docs/architecture/system-design.md`](docs/architecture/system-design.md) | System design and API sketch |

## Objective

Rebuild the organization's digital platform with a modern, accessible, responsive, maintainable, and secure architecture.

**Near-term delivery** is the public website MVP above. Later phases may add admin CMS, richer workflows, and other capabilities — only with approved requirements.

Longer-term platform themes (not all in MVP):

* Public website
* Backend API
* Administrative dashboard (post-MVP)
* Content and media management (post-MVP CMS)
* News and stories
* Programs and projects
* Gallery
* Contact handling
* Donation-related information (static in MVP)
* Authentication and authorization (post-MVP)
* SEO, accessibility, performance, testing, production infrastructure

## Core Principles

1. Build around the organization's real needs.
2. Preserve important existing content and organizational information.
3. Do not invent organizational facts.
4. Prioritize accessibility and mobile usability.
5. Keep the architecture maintainable.
6. Minimize unnecessary technical complexity.
7. Protect organizational and user data.
8. Document important technical decisions.
9. Test before production deployment.
10. Make the final system maintainable after handover.

## Repository Structure

```text
docs/             Project documentation and specifications
extracted_data/   Preserved WordPress extraction evidence (do not treat as approved publish set)
frontend/         Public-facing web application (scaffold later)
backend/          Backend API and business logic (scaffold later)
admin/            Administrative dashboard (out of MVP)
infra/            Deployment and infrastructure configuration
scripts/          Development and operational scripts
tests/            Cross-system testing
assets/           Project assets used during development
```

## Current Phase

### Docs-first gate (active)

Complete and review the documentation package before creating application code:

* Audit inventories and unknowns — `docs/audit/`
* MVP requirements and migration plan — `docs/product/`
* Architecture and ADRs — `docs/architecture/`
* Operations and acceptance — `docs/operations/`, `docs/testing/`

No production migration or destructive changes during this gate.

## Documentation

See:

* `docs/audit/` — Current system audit
* `docs/product/` — Product requirements
* `docs/architecture/` — System architecture and ADRs
* `docs/operations/` — Runbook
* `docs/testing/` — Acceptance checklist
* `docs/api/` — API documentation (to expand with OpenAPI later)
* `docs/design/` — Design system and UX (to expand in P2)
* `docs/development/` — Development standards (to expand in P3)
* `docs/deployment/` — Deployment documentation (see also operations runbook)

## Important

This repository is a volunteer project created to support the organization's mission.

Any production deployment, credentials, organizational data, payment configuration, or third-party service integration must be handled with appropriate authorization from the organization.
